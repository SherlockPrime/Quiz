const quiz = document.getElementById("quiz");
const question = document.getElementById('question');
const submit = document.getElementById('submit');
const ans_text = document.getElementById('ans_text');

document.write('<scripts src="///login_in.js"></scripts>');


alert(quizQ);

let currentQuiz = 0;
let score = 0;
document.addEventListener("keypress", function() {
  if (event.keyCode === 13) {
    submit.click();
  }
  });

submit.addEventListener('click', () => {
    if(ans_text_value === quizData[currentQuiz].correct) {
      score++;
    }
    currentQuiz++;
    if(currentQuiz < quizData.length) {
      loadQuiz();
      document.getElementById('ans_text').value='';
    } else {
      quiz.innerHTML = `<h2> You answered correctly ${score}/${quizData.length} question.</h2>
                        <button><a href="/main" style="a:visited">홈으로</a></button>
                        `; 
    }
});