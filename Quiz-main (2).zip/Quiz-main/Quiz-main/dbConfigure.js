var dbConfigure = {
  host : 'localhost',
  port : 3306,
  user : 'root',
  password : '1976025688',
  database : 'quizgame'
};

module.exports = dbConfigure;
